 $(document) .ready (function () { 
  $(window) .scroll (function () { 
     if ($(this) .scrollTop ()> 200) { 
        $(".bg-sticky").css('top', "0px");
    } else {
        $(".bg-sticky").css('top', "calc(-72px)");
    }
});
});
 $(document) .ready (function () { 
   $(window) .scroll (function () { 
      if ($(this) .scrollTop ()> 200) { 
         $(".bg-sticky").css('top', "0px");
     } else {
         $(".bg-sticky").css('top', "calc(-72px)");
     }
 });
});
 var btn=document.getElementById("search-button");
 btn.onclick=function(){
  $("#m1").css('display', "flex");
  $("#m2").css('display', "flex");
  $("#m3").css('display', "flex");
}
var buttoninf=document.getElementById("infbutton");
buttoninf.onclick=function(){
  $(".a6-5-2FHIJw").css('display', "flex");
  $(".a6-5-2_5MSu").css('display', "flex");
}
var mapbtnn=document.getElementById("mapbtn");
mapbtnn.onclick=function(){
  $("#bm1").css('display', "flex");
  $("#bm2").css('display', "flex");
  $("#bm3").css('display', "flex");
}
var shpcard=document.getElementById("shopcard");
shpcard.onclick=function(){
  $("#card1").css('display', "flex");
  $("#card2").css('display', "flex");
  $("#card6").css('display', "flex");
}
var shpcardd=document.getElementById("shopcard2");
shpcardd.onclick=function(){
  $("#card1").css('display', "flex");
  $("#card2").css('display', "flex");
  $("#card6").css('display', "flex");
  $(".a6-5-2xutoq").css('display', "none");
  $(".a6-4-1xUToq").css('display', "none");
}
var crdclose=document.getElementById("cardclose");
crdclose.onclick=function(){
  $("#card1").css('display', "none");
  $("#card2").css('display', "none");
  $("#card6").css('display', "none");
  $(".a6-5-2xutoq").css('display', "flex");
  $(".a6-4-1xUToq").css('display', "flex");
}
var crdclosee=document.getElementById("cardclose2");
crdclosee.onclick=function(){
   $("#card1").css('display', "none");
   $("#card2").css('display', "none");
   $("#card6").css('display', "none");
   $(".a6-5-2xutoq").css('display', "flex");
   $(".a6-4-1xUToq").css('display', "flex");
}
$('.closee').click(function() {
    $(".a6-5-2XItK4").css('display', "none");
    $(".a6-5-2KtxAY").css('display', "none");
    $(".a6-5-2_MzTS").css('display', "none");
    $(".a6-5-2FHIJw").css('display', "none");
    $(".a6-5-2_5MSu").css('display', "none");
    $("#uptmdl").css('display', "none");
    $("#notemodal").css('display', "none");
    $(".a5-4-0FHIJw").css('display', "none");
    var body = document.body;
    body.classList.remove("a6-5-2Qb9Nw");
    body.classList.remove("temp-hide-popups");
}); 
$('.item-card').click(function() {
  
   $(".a6-5-2XItK4").css('display', "flex");
   $("#modal"+gelenid).css('display', "flex");
   $(".a6-5-2_MzTS").css('display', "flex");
   var body = document.body;
   body.classList.add("a6-5-2Qb9Nw");
   body.classList.add("temp-hide-popups");
});
$('.cko__back-btn').click(function() {
   $(".cko--open").addClass("cko--close");
});
$('#checkopen').click(function() {
   $(".cko--close").addClass("cko--open");
   $(".cko--close").removeClass("cko--close");
});
$('#updatelocation').click(function() {
   $("#uptmdl").css('display', "flex");
});
$('#addordernote').click(function() {
   $("#notemodal").css('display', "flex");
   $(".a5-4-0FHIJw").css('display', "flex");
});
$('#searchnavi').click(function(){
   $(".navigation__search").addClass("search-open");
   $("#inpt1").removeClass("form_SearchInput_isToggleOff--3LhhO");
});
$('#addcoupon').click(function() {
   $("#addcoupon1").css('display', "none");
   $("#addcoupon").css('display', "none");
   $("#inputcoupon").css('display', "flex");
   $("#coupon1").addClass("coupon-code-container");
   $("#coupon1").removeClass("font--small");
});
$('#gift1').click(function() {
   $("#giftinput").css('display', "flex");
   $("#gift1").css('display', "none");
});
$('#cancel1').click(function() {
   $("#giftinput").css('display', "none");
   $("#gift1").css('display', "flex");
});
$(function(){
   $('*').click(function(e){
      if ( !$(e.target).is('.navigation__search') && !$(e.target).is('.navigation__search *') ){
        $(".navigation__search").removeClass("search-open");
        $("#inpt1").addClass("form_SearchInput_isToggleOff--3LhhO");
    }
    if ( !$(e.target).is('.modal') && !$(e.target).is('.modal *') &&  !$(e.target).is('.grid__item *') &&  !$(e.target).is('.mengel *')){
        $(".a6-5-2KtxAY").css('display', "none");
        $(".a6-5-2XItK4").css('display', "none");
        $(".a6-5-2FHIJw").css('display', "none");
        $(".a6-5-2_5MSu").css('display', "none");
        $(".a6-5-2_MzTS").css('display', "none");
        $("body").removeClass("a6-5-2Qb9Nw");
        $("body").removeClass("temp-hide-popups");
        $("#card1").css('display', "none");
    }
});
});
$('.category1').click(function() {
   var gelenid= $(this).attr('id');
   var beverages =document.getElementById('x'+gelenid).getBoundingClientRect(),
   top=Math.round(beverages.top-80);
   window.scrollBy(0,top);
   $('.mkat a').removeClass("active-nav-item");
   $(this).addClass("active-nav-item");




});
$('.categorym').click(function() {
   var gelenid= $(this).attr('id'); 
   $(".a6-5-2KtxAY").css('display', "none");
   $(".a6-5-2XItK4").css('display', "none");
   var beverages =document.getElementById('x'+gelenid).getBoundingClientRect(),
   top=Math.round(beverages.top-50);
   window.scrollBy(0,top)
});